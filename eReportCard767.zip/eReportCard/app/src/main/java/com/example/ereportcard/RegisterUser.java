package com.example.ereportcard;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.firebase.database.FirebaseDatabase;

import java.util.HashMap;
import java.util.Map;

public class RegisterUser extends AppCompatActivity {

    EditText register_userName, register_password, register_confirmPassword;
    Button btnRegister;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register_user);

        //changing the status bar color
        getWindow().setStatusBarColor(ContextCompat.getColor(this,R.color.yellow));

        register_userName = findViewById(R.id.txtRegister_UserName);
        register_password = findViewById(R.id.txtRegister_Password);
        register_confirmPassword = findViewById(R.id.txtRegister_Confirm_Password);
        btnRegister = findViewById(R.id.btnRegister);

        register_userName.requestFocus();


        btnRegister.setOnClickListener(view -> {

            //logging in user
            String username = register_userName.getText().toString().trim();
            String pass = register_password.getText().toString().trim();
            String confirmPass = register_confirmPassword.getText().toString().trim();

            //method of user validation
            boolean check = validateUser(username,pass,confirmPass);

            if (check){
                //encrypting user password
                MD5Encryption encryption = new MD5Encryption(pass);
                String password = encryption.getEncryption();


                //inserting data into database
                Map<String, Object> map = new HashMap<>();
                map.put("registerUsername", username);
                map.put("registerPassword", password);

                FirebaseDatabase.getInstance().getReference("MobileUsers").child("Registered_Users").child(username).setValue(map)
                        .addOnSuccessListener(unused -> {
                            Toast.makeText(RegisterUser.this, "Successfully Inserted.", Toast.LENGTH_SHORT).show();

                            register_userName.setText("");
                            register_password.setText("");
                            register_confirmPassword.setText("");

                        })
                        .addOnFailureListener(e -> Toast.makeText(RegisterUser.this, "Error While Inserting.", Toast.LENGTH_SHORT).show());
                startActivity(new Intent(getApplicationContext(), Login.class));
            }
            else {
                Toast.makeText(RegisterUser.this, "Sorry, Cannot be registered at this time.", Toast.LENGTH_SHORT).show();
            }

        });
    }
    //method for validating user at registration.
    private boolean validateUser(String username, String pass, String confirmPass) {

        if (register_userName.length()==0){
            register_userName.requestFocus();
            register_userName.setError("Username Can't be Empty.");
            return false;
        }
        else if (!username.matches("[a-zA-Z]+")){
            register_userName.requestFocus();
            register_userName.setError("Enter Only Alphabetical Characters.");
            return false;
        }
        else if (pass.length() <= 5){
            register_password.requestFocus();
            register_password.setError("Minimum of 6 Characters Required.");
            return false;
        }
        else if (!pass.equals(confirmPass)) {
            register_confirmPassword.requestFocus();
            register_confirmPassword.setError("Passwords do not match.");
            return false;
        }else{
            return true;
        }
    }

}