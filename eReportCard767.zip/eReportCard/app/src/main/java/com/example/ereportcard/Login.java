package com.example.ereportcard;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.Objects;

public class Login extends AppCompatActivity {

    EditText userName, password;
    TextView registerUser, loading;
    CheckBox remember;
    Button btnLogin;

    DatabaseReference database;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        //changing the status bar color
        getWindow().setStatusBarColor(ContextCompat.getColor(this,R.color.green));

        userName = findViewById(R.id.txtUserName);
        password = findViewById(R.id.txtPassword);
        remember = findViewById(R.id.rememnerME);
        btnLogin = findViewById(R.id.btnLogin);
        registerUser = findViewById(R.id.lblRegister);
        loading = findViewById(R.id.lblLoading);

        userName.requestFocus();

        loading.setVisibility(View.GONE);


        //checking if user selected remember me while login in on new app startup.
        SharedPreferences preferences = getSharedPreferences("checkbox", MODE_PRIVATE);
        String checkbox = preferences.getString("remember", "");
        String userNAME = preferences.getString("username", "");

        if (checkbox.equals("true")){
            userName.setText(userNAME);
            Intent intent = new Intent(Login.this, ChooseChild.class);
            intent.putExtra("userName",userNAME);
            startActivity(intent);

        }

        btnLogin.setOnClickListener(view -> {

            loading.setVisibility(View.VISIBLE);

            //logging in user
            String username = userName.getText().toString().trim();
            String pass = password.getText().toString().trim();

            //method of user validation
            boolean check = validateUser(username,pass);

            if (check){


                //getting child courses from database for current school year and school term.
                database = FirebaseDatabase.getInstance().getReference("MobileUsers").child("Registered_Users").child(username);

                database.addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        if (snapshot.exists()){
                            String UserID = Objects.requireNonNull(snapshot.child("registerUsername").getValue()).toString();
                            String UserPASSWORD = Objects.requireNonNull(snapshot.child("registerPassword").getValue()).toString();

                            //encryption
                            MD5Encryption encryption = new MD5Encryption(pass);
                            String password = encryption.getEncryption();

                            if (!username.equals(UserID) || !password.equals(UserPASSWORD)){

                                //Checking if rememberMe is checked while fields don't match credentials from database.
                                if (remember.isChecked()){

                                    //rememberMe info is not stored
                                    SharedPreferences preferences1 = getSharedPreferences("checkbox", MODE_PRIVATE);
                                    SharedPreferences.Editor editor = preferences1.edit();
                                    editor.putString("remember", "false");
                                    editor.apply();
                                    loading.setVisibility(View.GONE);
                                    Toast.makeText(Login.this, "User does not exists.", Toast.LENGTH_LONG).show();
                                }
                            }else{

                                //Checking if rememberMe is checked while fields matches credentials from database.
                                if (remember.isChecked()){

                                    //storing rememberMe info.
                                    SharedPreferences preferences1 = getSharedPreferences("checkbox", MODE_PRIVATE);
                                    SharedPreferences.Editor editor = preferences1.edit();
                                    editor.putString("remember", "true");
                                    editor.putString("username", userName.getText().toString().trim());
                                    editor.apply();

                                    Intent intent = new Intent(Login.this, ChooseChild.class);
                                    intent.putExtra("userName",UserID);
                                    startActivity(intent);

                                }
                                Intent intent = new Intent(Login.this, ChooseChild.class);
                                intent.putExtra("userName", UserID);
                                startActivity(intent);


                            }
                        }else{
                            loading.setVisibility(View.GONE);
                            Toast.makeText(Login.this, "User does not exists.", Toast.LENGTH_LONG).show();
                            userName.setText("");
                            password.setText("");
                            userName.requestFocus();
                        }
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {
                        loading.setVisibility(View.GONE);
                    }
                });
            }else{
                loading.setVisibility(View.GONE);
            }

        });

        //clicking the authenticated click here to launch the register screen.
        registerUser.setOnClickListener(view -> startActivity(new Intent(getApplicationContext(), RegisterUser.class)));
    }

    //function to validate user login.
    private Boolean validateUser(String username, String pass) {
        if (username.length()==0){
            userName.requestFocus();
            userName.setError("Username Can't be Empty.");
            return false;
        }
        else if (!username.matches("[a-zA-Z]+")){
            userName.requestFocus();
            userName.setError("Enter Only Alphabetical Characters.");
            return false;
        }
        else if (pass.length() <= 5){
            password.requestFocus();
            password.setError("Minimum of 6 Characters Required.");
            return false;
        }
        else{
            return true;
        }
    }

    @Override
    public void onBackPressed() {
        finishAffinity();
    }
}