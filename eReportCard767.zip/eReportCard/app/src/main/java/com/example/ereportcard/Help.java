package com.example.ereportcard;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.Objects;

public class Help extends AppCompatActivity {

    TextView help_AddChild, help_ViewReportCard, help_SearchPreviousReportcard, help_Registration, help_Login;
    LinearLayout layout_help_login, layout_help_addChild, layout_help_viewReportCard, layout_help_search_ReportCard, layout_help_registration;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_help);

        //changing the status bar color
        getWindow().setStatusBarColor(ContextCompat.getColor(this,R.color.orange));

        //changing the action bar color
        Objects.requireNonNull(getSupportActionBar()).setBackgroundDrawable(new ColorDrawable(Color.parseColor("#FF5722")));

        Objects.requireNonNull(getSupportActionBar()).setTitle("Help");

        help_AddChild = findViewById(R.id.help_addChild);
        help_ViewReportCard = findViewById(R.id.help_view_child_reportcard);
        help_SearchPreviousReportcard = findViewById(R.id.help_search_previous_reportcard);
        help_Registration = findViewById(R.id.help_registration);
        help_Login = findViewById(R.id.help_login);

        layout_help_addChild = findViewById(R.id.layout_help_addChild);
        layout_help_login = findViewById(R.id.layout_help_login);
        layout_help_viewReportCard = findViewById(R.id.layout_help_view_reportcard);
        layout_help_search_ReportCard = findViewById(R.id.layout_help_search_previous_reportcard);
        layout_help_registration = findViewById(R.id.layout_help_registering);


        //showing help window of help categories
        final String[] v = {"p"};
        //opening window
        help_AddChild.setOnClickListener(view -> {
            if (Objects.equals(v[0], "p")) {
                help_AddChild.setTextColor(Color.BLUE);
                layout_help_addChild.setVisibility(View.VISIBLE);
                layout_help_login.setVisibility(View.GONE);
                layout_help_registration.setVisibility(View.GONE);
                layout_help_search_ReportCard.setVisibility(View.GONE);
                layout_help_viewReportCard.setVisibility(View.GONE);
                v[0] = "q";
            }else if (Objects.equals(v[0], "q")){
                //closing window
                layout_help_addChild.setVisibility(View.GONE);
                help_AddChild.setTextColor(Color.GRAY);
                v[0] = "p";
            }

        });

        //showing help window of help categories
        //opening window
        help_Login.setOnClickListener(view -> {
            if (Objects.equals(v[0], "p")) {
                help_Login.setTextColor(Color.BLUE);
                layout_help_login.setVisibility(View.VISIBLE);
                layout_help_addChild.setVisibility(View.GONE);
                layout_help_registration.setVisibility(View.GONE);
                layout_help_search_ReportCard.setVisibility(View.GONE);
                layout_help_viewReportCard.setVisibility(View.GONE);
                v[0] = "q";
            }else if (Objects.equals(v[0], "q")){
                //closing window
                layout_help_login.setVisibility(View.GONE);
                help_Login.setTextColor(Color.GRAY);
                v[0] = "p";
            }

        });

        //showing help window of help categories
        //opening window
        help_Registration.setOnClickListener(view -> {
            if (Objects.equals(v[0], "p")) {
                help_Registration.setTextColor(Color.BLUE);
                layout_help_login.setVisibility(View.GONE);
                layout_help_addChild.setVisibility(View.GONE);
                layout_help_registration.setVisibility(View.VISIBLE);
                layout_help_search_ReportCard.setVisibility(View.GONE);
                layout_help_viewReportCard.setVisibility(View.GONE);
                v[0] = "q";
            }else if (Objects.equals(v[0], "q")){
                //closing window
                layout_help_registration.setVisibility(View.GONE);
                help_Registration.setTextColor(Color.GRAY);
                v[0] = "p";
            }
        });

        //showing help window of help categories
        //opening window
        help_SearchPreviousReportcard.setOnClickListener(view -> {
            if (Objects.equals(v[0], "p")) {
                help_SearchPreviousReportcard.setTextColor(Color.BLUE);
                layout_help_login.setVisibility(View.GONE);
                layout_help_addChild.setVisibility(View.GONE);
                layout_help_registration.setVisibility(View.GONE);
                layout_help_search_ReportCard.setVisibility(View.VISIBLE);
                layout_help_viewReportCard.setVisibility(View.GONE);
                v[0] = "q";
            }else if (Objects.equals(v[0], "q")){
                //closing window
                layout_help_search_ReportCard.setVisibility(View.GONE);
                help_SearchPreviousReportcard.setTextColor(Color.GRAY);
                v[0] = "p";
            }
        });

        //showing help window of help categories
        //opening window
        help_ViewReportCard.setOnClickListener(view -> {
            if (Objects.equals(v[0], "p")) {
                help_ViewReportCard.setTextColor(Color.BLUE);
                layout_help_login.setVisibility(View.GONE);
                layout_help_addChild.setVisibility(View.GONE);
                layout_help_registration.setVisibility(View.GONE);
                layout_help_search_ReportCard.setVisibility(View.GONE);
                layout_help_viewReportCard.setVisibility(View.VISIBLE);
                v[0] = "q";
            }else if (Objects.equals(v[0], "q")){
                //closing window
                layout_help_viewReportCard.setVisibility(View.GONE);
                help_ViewReportCard.setTextColor(Color.GRAY);
                v[0] = "p";
            }
        });
    }
}