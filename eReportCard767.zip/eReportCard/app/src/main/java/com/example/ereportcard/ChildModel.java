package com.example.ereportcard;

public class ChildModel {
    String firstName, lastName, childID, school, classID, userID;

    //empty constructor needed for firebase
    ChildModel()
    {

    }

    public ChildModel(String firstName, String lastName, String childID, String school, String classID) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.childID = childID;
        this.school = school;
        this.classID = classID;
        this.userID = userID;

    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getChildID() {
        return childID;
    }

    public void setChildID(String childID) {
        this.childID = childID;
    }

    public String getSchool() {
        return school;
    }

    public void setSchool(String school) {
        this.school = school;
    }

    public String getClassID() {
        return classID;
    }

    public void setClassID(String classID) {
        this.classID = classID;
    }

    public String getUserID() {
        return userID;
    }

    public void setUserID(String userID) {
        this.userID = userID;
    }
}
