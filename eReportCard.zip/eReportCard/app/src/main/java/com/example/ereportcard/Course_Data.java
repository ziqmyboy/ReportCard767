package com.example.ereportcard;

public class Course_Data {
    String courseName, courseTermGrade, courseExamGrade, courseTeacher, courseComments, id;

    public String getCourseName() {
        return courseName;
    }

    public String getCourseTermGrade() {
        return courseTermGrade;
    }

    public String getCourseExamGrade() {
        return courseExamGrade;
    }

    public String getCourseTeacher() {
        return courseTeacher;
    }

    public String getCourseComments() {
        return courseComments;
    }

    public String getId() {
        return id;
    }
}
