package com.example.ereportcard;

import android.app.AlertDialog;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.google.firebase.database.FirebaseDatabase;

import java.util.Objects;

public class ChildAdapter extends FirebaseRecyclerAdapter<ChildModel,ChildAdapter.myViewHolder> {

    /**
     * Initialize a {@link RecyclerView.Adapter} that listens to a Firebase query. See
     * {@link FirebaseRecyclerOptions} for configuration options.
     *
     */
    public ChildAdapter(@NonNull FirebaseRecyclerOptions<ChildModel> options) {
        super(options);
    }

    @Override
    protected void onBindViewHolder(@NonNull myViewHolder holder, int position, @NonNull ChildModel model) {

        holder.firstName.setText(model.getFirstName());
        holder.lastName.setText(model.getLastName());
        holder.childID.setText(model.getChildID());
        holder.school.setText(model.getSchool());
        holder.classID.setText(model.getClassID());
        holder.userID.setText(model.getUserID());


        //setting click listeners for every item in the recyclerview.
        holder.itemView.setOnClickListener(view -> {

            //saving child info after selection to show respective reportcard.

            Intent intent = new Intent(holder.firstName.getContext(), ReportCardView.class);
            intent.putExtra("firstName",model.getFirstName());
            intent.putExtra("lastName",model.getLastName());
            intent.putExtra("childID",model.getChildID());
            intent.putExtra("classID",model.getClassID());
            intent.putExtra("school",model.getSchool());
            holder.firstName.getContext().startActivity(intent);

        });
        //deleting a child
        holder.deleteButton.setOnClickListener(view -> {
            AlertDialog.Builder builder = new AlertDialog.Builder(holder.firstName.getContext());
            builder.setTitle("Warning!");
            builder.setMessage(holder.firstName.getText().toString()+"'s Deleted data can't be undone.");

            builder.setPositiveButton("Delete", (dialogInterface, i) -> {
                //delete code goes here
                FirebaseDatabase.getInstance().getReference("MobileUsers").child("Registered_Users").child(holder.userID.getText().toString()).child("childInfo")
                        .child(Objects.requireNonNull(getRef(holder.getAdapterPosition()).getKey())).removeValue();
            });
            builder.setNegativeButton("Cancel", (dialogInterface, i) -> Toast.makeText(holder.firstName.getContext(), "Cancelled", Toast.LENGTH_SHORT).show());
            builder.show();
        });
    }

    @NonNull
    @Override
    public myViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.student_item,parent,false);
        return new myViewHolder(view);
    }

    static class myViewHolder extends RecyclerView.ViewHolder{
        TextView firstName, lastName, childID, school, classID, userID;
        ImageView deleteButton;

        public myViewHolder(@NonNull View itemView) {
            super(itemView);


            firstName = (TextView)itemView.findViewById(R.id.txtFirstName);
            lastName = (TextView)itemView.findViewById(R.id.txtLastName);
            childID = (TextView)itemView.findViewById(R.id.txtStudentID);
            school = (TextView)itemView.findViewById(R.id.txtSchool);
            classID = (TextView)itemView.findViewById(R.id.txtClass);

            userID = (TextView)itemView.findViewById(R.id.txtUser_RegisteredID);

            deleteButton = (ImageView)itemView.findViewById(R.id.btnDelete);

        }
    }
}