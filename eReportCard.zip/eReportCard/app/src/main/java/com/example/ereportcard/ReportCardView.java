package com.example.ereportcard;

import android.annotation.SuppressLint;
import android.app.Dialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Objects;

public class ReportCardView extends AppCompatActivity {

    //TODO
    //KEEP ADDING SCHOOL YEARS EVERY YEAR.

    String[] school_Term = {"1st Term", "2nd Term", "3rd Term"};
    String[] school_Year = {"2021 - 2022", "2022 - 2023", "2023 - 2024", "2024 - 2025", "2025 - 2026", "2026 - 2027", "2027 - 2028", "2028 - 2029", "2029 - 2030", "2030 - 2031", "2031 - 2032"};
    String[] primaryID = {"Grade K", "Grade 1", "Grade 2", "Grade 3", "Grade 4", "Grade 5", "Grade 6"};

    //TODO
    /*uncomment the secondaryID along with the corresponding if statement in the spinner
     section further down when secondary schools come onboard.*/
    //String[] secondaryID = {"1st Form", "2nd Form", "3rd Form", "4th Form", "5th Form"};

    TextView  childID, childName, classID, co_operation, conduct, examAverage, generalComments, industry, personalAppearance, punctuality, regularity, reliability, schoolTerm, schoolYear, socialRelationship, sportsmanship, termAverage, principalComments, message,
            teacher_Signature_Date, principal_Signature_Date, promotion_Status;

    RecyclerView recyclerView;
    DatabaseReference database, db;
    CourseAdapter courseAdapter;
    ArrayList<Course_Data> list;
    ScrollView scrollView;

    ProgressBar progressBar;

    public String FIRSTNAME, LASTNAME, CHILDID, CLASSID, SCHOOL;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_report_card_view);

        //changing the status bar color
        getWindow().setStatusBarColor(ContextCompat.getColor(this,R.color.red));

        //changing the action bar color
        Objects.requireNonNull(getSupportActionBar()).setBackgroundDrawable(new ColorDrawable(Color.parseColor("red")));

        FIRSTNAME = getIntent().getStringExtra("firstName");
        LASTNAME = getIntent().getStringExtra("lastName");
        CHILDID = getIntent().getStringExtra("childID");
        CLASSID = getIntent().getStringExtra("classID");
        SCHOOL = getIntent().getStringExtra("school");

        //getting the current calendar year.
        int current_YEAR = Calendar.getInstance().get(Calendar.YEAR);

        //getting the current calendar month.
        int calendarMonth = Calendar.getInstance().get(Calendar.MONTH) + 1;

        //setting variables
        int previous_YEAR, next_YEAR;
        String school_YEAR, school_TERM;

        //assigning current and nxt year's values to variables.
        previous_YEAR = current_YEAR -1;
        next_YEAR = current_YEAR +1;


        childID = findViewById(R.id.lblStudentID);
        childName = findViewById(R.id.lblStudentName);
        classID = findViewById(R.id.lblClassID);

        co_operation = findViewById(R.id.lblCooperation);
        conduct = findViewById(R.id.lblConduct);
        examAverage = findViewById(R.id.lblExamAverage);
        generalComments = findViewById(R.id.lblGeneralComments);
        industry = findViewById(R.id.lblIndustry);
        personalAppearance = findViewById(R.id.lblPersonalAppearance);
        principal_Signature_Date = findViewById(R.id.lblPrincipal_Signature_Date);
        punctuality = findViewById(R.id.lblPunctuality);
        regularity = findViewById(R.id.lblRegularity);
        reliability = findViewById(R.id.lblReliability);
        schoolTerm = findViewById(R.id.lblSchoolTerm);
        schoolYear = findViewById(R.id.lblSchoolYear);
        socialRelationship = findViewById(R.id.lblSocialRelationship);
        sportsmanship = findViewById(R.id.lblSportsmanship);
        teacher_Signature_Date = findViewById(R.id.lblTeacher_Signature_Date);
        termAverage = findViewById(R.id.lblTermAverage);
        principalComments = findViewById(R.id.lblPrincipalComments);
        promotion_Status = findViewById(R.id.lbl_PromotionStatus);

        message = findViewById(R.id.lblMessage);

        recyclerView = findViewById(R.id.courseDataList);

        //checking what month we are currently in other to make a database call.
        if (calendarMonth <= 4){

            //setting current school Year.
            school_YEAR = previous_YEAR+" - "+current_YEAR;

            //setting current school Term.
            school_TERM = "2nd Term";

            examAverage.setVisibility(View.GONE);

            //getting child courses from database for current school year and school term.
            database = FirebaseDatabase.getInstance().getReference("REPORTCARD").child(SCHOOL).child(CLASSID).child(school_YEAR).child(school_TERM).child(FIRSTNAME+" "+LASTNAME).child("COURSES");

            //TODO
            //make a function for the above statements.

        }else if (calendarMonth <= 8){

            //setting current school Year.
            school_YEAR = previous_YEAR+" - "+current_YEAR;

            //setting current school Term.
            school_TERM = "3rd Term";

            //setting Promotion status to show once its 3rd term.
            promotion_Status.setVisibility(View.VISIBLE);

            //getting child courses from database for current school year and school term.
            database = FirebaseDatabase.getInstance().getReference("REPORTCARD").child(SCHOOL).child(CLASSID).child(school_YEAR).child(school_TERM).child(FIRSTNAME+" "+LASTNAME).child("COURSES");

            //TODO
            //make a function for the above statements.

        }else if(calendarMonth <= 12){

            //setting current school Year.
            school_YEAR = current_YEAR+" - "+next_YEAR;

            //setting current school Term.
            school_TERM = "1st Term";

            //getting child courses from database for current school year and school term.
            database = FirebaseDatabase.getInstance().getReference("REPORTCARD").child(SCHOOL).child(CLASSID).child(school_YEAR).child(school_TERM).child(FIRSTNAME+" "+LASTNAME).child("COURSES");

            //TODO
            //make a function for the above statements.
        }
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false));

        list = new ArrayList<>();
        courseAdapter = new CourseAdapter(this, list);
        recyclerView.setAdapter(courseAdapter);

        scrollView = findViewById(R.id.scrollView);

        progressBar = new ProgressBar(this);
        progressBar.ShowDialog("Loading " + FIRSTNAME+"'s ReportCard.");

        //getting course info
        database.addValueEventListener(new ValueEventListener() {
            @SuppressLint("NotifyDataSetChanged")
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                list.clear();
                for (DataSnapshot dataSnapshot : snapshot.getChildren()){
                    Course_Data course_data = dataSnapshot.getValue(Course_Data.class);
                    list.add(course_data);

                }
                courseAdapter.notifyDataSetChanged();

                progressBar.HideDialog();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });

        //getting rest of reportcard info
        //checking what month we are currently in other to make a database call.
        if (calendarMonth <= 4){

            //setting current school Year.
            school_YEAR = previous_YEAR+" - "+current_YEAR;

            //setting current school Term.
            school_TERM = "2nd Term";

            //getting child courses from database for current school year and school term.
            db = FirebaseDatabase.getInstance().getReference("REPORTCARD").child(SCHOOL).child(CLASSID).child(school_YEAR).child(school_TERM).child(FIRSTNAME+" "+LASTNAME).child(CHILDID);

            //TODO
            //make a function for the above statements.

        }else if (calendarMonth <= 8){

            //setting current school Year.
            school_YEAR = previous_YEAR+" - "+current_YEAR;

            //setting current school Term.
            school_TERM = "3rd Term";

            //getting child courses from database for current school year and school term.
            db = FirebaseDatabase.getInstance().getReference("REPORTCARD").child(SCHOOL).child(CLASSID).child(school_YEAR).child(school_TERM).child(FIRSTNAME+" "+LASTNAME).child(CHILDID);

            //TODO
            //make a function for the above statements.

        }else if(calendarMonth <= 12){

            //setting current school Year.
            school_YEAR = current_YEAR+" - "+next_YEAR;

            //setting current school Term.
            school_TERM = "1st Term";

            //getting child courses from database for current school year and school term.
            db = FirebaseDatabase.getInstance().getReference("REPORTCARD").child(SCHOOL).child(CLASSID).child(school_YEAR).child(school_TERM).child(FIRSTNAME+" "+LASTNAME).child(CHILDID);

            //TODO
            //make a function for the above statements.
        }
        db.addValueEventListener(new ValueEventListener() {
            @SuppressLint({"ResourceAsColor", "SetTextI18n"})
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {

                if (snapshot.exists()) {
                    String cID = Objects.requireNonNull(snapshot.child("childID").getValue()).toString();
                    String childName1 = Objects.requireNonNull(snapshot.child("childName").getValue()).toString();
                    String classID1 = Objects.requireNonNull(snapshot.child("classID").getValue()).toString();
                    String co_operation1 = Objects.requireNonNull(snapshot.child("co_operation").getValue()).toString();
                    String conduct1 = Objects.requireNonNull(snapshot.child("conduct").getValue()).toString();
                    String examAverage1 = "Exam:        " + Objects.requireNonNull(snapshot.child("examAverage").getValue());
                    String generalComments1 = Objects.requireNonNull(snapshot.child("generalComments").getValue()).toString();
                    String industry1 = Objects.requireNonNull(snapshot.child("industry").getValue()).toString();
                    String personalAppearance1 = Objects.requireNonNull(snapshot.child("personalAppearance").getValue()).toString();
                    String principalSignatureDate1 = Objects.requireNonNull(snapshot.child("principal_SignatureDate").getValue()).toString();
                    String punctuality1 = Objects.requireNonNull(snapshot.child("punctuality").getValue()).toString();
                    String regularity1 = Objects.requireNonNull(snapshot.child("regularity").getValue()).toString();
                    String reliability1 = Objects.requireNonNull(snapshot.child("reliability").getValue()).toString();
                    String schoolTerm1 = Objects.requireNonNull(snapshot.child("schoolTerm").getValue()).toString();
                    String schoolYear1 = Objects.requireNonNull(snapshot.child("schoolYear").getValue()).toString();
                    String socialRelationship1 = Objects.requireNonNull(snapshot.child("socialRelationship").getValue()).toString();
                    String sportsmanship1 = Objects.requireNonNull(snapshot.child("sportsmanship").getValue()).toString();
                    String teacherSignatureDate1 = Objects.requireNonNull(snapshot.child("teacher_SignatureDate").getValue()).toString();
                    String termAverage1 = "Term:         " + Objects.requireNonNull(snapshot.child("termAverage").getValue());
                    String principalComments1 = Objects.requireNonNull(snapshot.child("principalComments").getValue()).toString();
                    String promotionStatus1 = Objects.requireNonNull(snapshot.child("promote_Status").getValue()).toString();

                    if (principalComments1.equals(" ")){
                        //hiding scrollView.
                        scrollView.setVisibility(View.GONE);

                        //setting text to show dashes.
                        childID.setText("----");
                        childName.setText("----");
                        classID.setText("----");
                        schoolTerm.setText("");
                        schoolYear.setText("");

                        message.setText(schoolTerm1+"'s ReportCard for\n"+FIRSTNAME +" "+ LASTNAME + "\ndoes not exist. " +
                                "Consider using the ReportCard Search menu,\nat the top right hand corner of your screen.");
                        message.setVisibility(View.VISIBLE);
                    }else {
                        childID.setText(cID);
                        childName.setText(childName1);
                        classID.setText(classID1);
                        co_operation.setText(co_operation1);
                        conduct.setText(conduct1);
                        examAverage.setText(examAverage1);
                        generalComments.setText(generalComments1);
                        industry.setText(industry1);
                        personalAppearance.setText(personalAppearance1);
                        principal_Signature_Date.setText(principalSignatureDate1);
                        punctuality.setText(punctuality1);
                        regularity.setText(regularity1);
                        reliability.setText(reliability1);
                        schoolTerm.setText(schoolTerm1);
                        schoolYear.setText(schoolYear1);
                        socialRelationship.setText(socialRelationship1);
                        sportsmanship.setText(sportsmanship1);
                        teacher_Signature_Date.setText(teacherSignatureDate1);
                        termAverage.setText(termAverage1);
                        principalComments.setText(principalComments1);
                        promotion_Status.setText(promotionStatus1);
                        if (schoolTerm1.equals("3rd Term")){promotion_Status.setVisibility(View.VISIBLE); if (promotionStatus1.equals("Repeated")){promotion_Status.setTextColor(Color.RED);
                        }else{promotion_Status.setTextColor(Color.GREEN);}}

                        message.setVisibility(View.GONE);
                        scrollView.setVisibility(View.VISIBLE);
                    }
                }else{
                    //hiding scrollView.
                    scrollView.setVisibility(View.GONE);

                    //setting text to show dashes.
                    childID.setText("----");
                    childName.setText("----");
                    classID.setText("----");
                    schoolTerm.setText("");
                    schoolYear.setText("");

                    message.setText("ReportCard for "+FIRSTNAME +" "+ LASTNAME + " does not exist.\n" +
                            "Consider using the ReportCard Search menu at the top right.");
                    message.setVisibility(View.VISIBLE);

                }
                progressBar.HideDialog();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }

    @SuppressLint("SetTextI18n")
    private void showDialog() {

        Dialog dialog = new Dialog(this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(R.layout.search_reportcard_bottom_dialog);
        Button search_ReportCard = dialog.findViewById(R.id.btnSearch_Reportcard);
        TextView search_header = dialog.findViewById(R.id.search_header_title);
        AutoCompleteTextView className = dialog.findViewById(R.id.class_Search_Spinner);
        AutoCompleteTextView reportcard_Term = dialog.findViewById(R.id.term_Search_Spinner);
        AutoCompleteTextView reportcard_Year = dialog.findViewById(R.id.year_Search_Spinner);
        ArrayAdapter<String> adapterItem;
        ArrayAdapter<String> school_Term_adapterItem;
        ArrayAdapter<String> school_Year_adapterItem;

        className.setText(CLASSID);

        //TODO
        //remove this section when secondary schools come onboard.

        adapterItem = new ArrayAdapter<>(this, R.layout.list_item, primaryID);
        school_Term_adapterItem = new ArrayAdapter<>(this, R.layout.list_item, school_Term);
        school_Year_adapterItem = new ArrayAdapter<>(this,R.layout.list_item,school_Year);

        className.setAdapter(adapterItem);
        reportcard_Term.setAdapter(school_Term_adapterItem);
        reportcard_Year.setAdapter(school_Year_adapterItem);

        //TODO
        //unComment the if statement when secondary schools come onboard.

        /*if (className.getText().toString().contains("4th Form")){
            adapterItem = new ArrayAdapter<>(this, R.layout.list_item, secondaryID);
            school_Term_adapterItem = new ArrayAdapter<>(this, R.layout.list_item, school_Term);
            school_Year_adapterItem = new ArrayAdapter<>(this,R.layout.list_item,school_Year);

            className.setAdapter(adapterItem);
            reportcard_Term.setAdapter(school_Term_adapterItem);
            reportcard_Year.setAdapter(school_Year_adapterItem);
        }else {

            adapterItem = new ArrayAdapter<>(this, R.layout.list_item, primaryID);
            school_Term_adapterItem = new ArrayAdapter<>(this, R.layout.list_item, school_Term);
            school_Year_adapterItem = new ArrayAdapter<>(this,R.layout.list_item,school_Year);

            className.setAdapter(adapterItem);
            reportcard_Term.setAdapter(school_Term_adapterItem);
            reportcard_Year.setAdapter(school_Year_adapterItem);

        }*/

        //clicking the search button
        search_ReportCard.setOnClickListener(view -> {

            String classname = className.getText().toString().trim();
            String reportCard_Term = reportcard_Term.getText().toString().trim();
            String reportCard_Year = reportcard_Year.getText().toString().trim();

            //Error checking.
            if (classname.isEmpty() ){
                Toast.makeText(ReportCardView.this, "classname cant be empty", Toast.LENGTH_SHORT).show();
            }else if (reportCard_Term.isEmpty()){
                Toast.makeText(ReportCardView.this, "Please Select School Term.", Toast.LENGTH_SHORT).show();
            }else if (reportCard_Year.isEmpty()){
                Toast.makeText(ReportCardView.this, "Please Select School Year.", Toast.LENGTH_SHORT).show();
            }else{
                //add code to search for specific reportcard
                database = FirebaseDatabase.getInstance().getReference("REPORTCARD").child(SCHOOL).child(classname).child(reportCard_Year).child(reportCard_Term).child(FIRSTNAME + " " + LASTNAME).child("COURSES");
                //getting course info
                database.addValueEventListener(new ValueEventListener() {
                    @SuppressLint("NotifyDataSetChanged")
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        list.clear();
                        for (DataSnapshot dataSnapshot : snapshot.getChildren()){
                            Course_Data course_data = dataSnapshot.getValue(Course_Data.class);
                            list.add(course_data);

                        }
                        courseAdapter.notifyDataSetChanged();

                        progressBar.HideDialog();
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {

                    }
                });

                //getting rest of reportcard info
                db = FirebaseDatabase.getInstance().getReference("REPORTCARD").child(SCHOOL).child(classname).child(reportCard_Year).child(reportCard_Term).child(FIRSTNAME+" "+LASTNAME).child(CHILDID);

                db.addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {

                        if (snapshot.exists()) {
                            message.setVisibility(View.GONE);

                            String cID = Objects.requireNonNull(snapshot.child("childID").getValue()).toString();
                            String childName1 = Objects.requireNonNull(snapshot.child("childName").getValue()).toString();
                            String classID1 = Objects.requireNonNull(snapshot.child("classID").getValue()).toString();
                            String co_operation1 = Objects.requireNonNull(snapshot.child("co_operation").getValue()).toString();
                            String conduct1 = Objects.requireNonNull(snapshot.child("conduct").getValue()).toString();
                            String examAverage1 = "Exam:        " + Objects.requireNonNull(snapshot.child("examAverage").getValue());
                            String generalComments1 = Objects.requireNonNull(snapshot.child("generalComments").getValue()).toString();
                            String industry1 = Objects.requireNonNull(snapshot.child("industry").getValue()).toString();
                            String personalAppearance1 = Objects.requireNonNull(snapshot.child("personalAppearance").getValue()).toString();
                            String principalSignatureDate1 = Objects.requireNonNull(snapshot.child("principal_SignatureDate").getValue()).toString();
                            String punctuality1 = Objects.requireNonNull(snapshot.child("punctuality").getValue()).toString();
                            String regularity1 = Objects.requireNonNull(snapshot.child("regularity").getValue()).toString();
                            String reliability1 = Objects.requireNonNull(snapshot.child("reliability").getValue()).toString();
                            String schoolTerm1 = Objects.requireNonNull(snapshot.child("schoolTerm").getValue()).toString();
                            String schoolYear1 = Objects.requireNonNull(snapshot.child("schoolYear").getValue()).toString();
                            String socialRelationship1 = Objects.requireNonNull(snapshot.child("socialRelationship").getValue()).toString();
                            String sportsmanship1 = Objects.requireNonNull(snapshot.child("sportsmanship").getValue()).toString();
                            String teacherSignatureDate1 = Objects.requireNonNull(snapshot.child("teacher_SignatureDate").getValue()).toString();
                            String termAverage1 = "Term:         " + Objects.requireNonNull(snapshot.child("termAverage").getValue());
                            String principalComments1 = Objects.requireNonNull(snapshot.child("principalComments").getValue()).toString();
                            String promotionStatus1 = Objects.requireNonNull(snapshot.child("promote_Status").getValue()).toString();


                            childID.setText(cID);
                            childName.setText(childName1);
                            classID.setText(classID1);
                            co_operation.setText(co_operation1);
                            conduct.setText(conduct1);
                            examAverage.setText(examAverage1);
                            generalComments.setText(generalComments1);
                            industry.setText(industry1);
                            personalAppearance.setText(personalAppearance1);
                            principal_Signature_Date.setText(principalSignatureDate1);
                            punctuality.setText(punctuality1);
                            regularity.setText(regularity1);
                            reliability.setText(reliability1);
                            schoolTerm.setText(schoolTerm1);
                            schoolYear.setText(schoolYear1);
                            socialRelationship.setText(socialRelationship1);
                            sportsmanship.setText(sportsmanship1);
                            teacher_Signature_Date.setText(teacherSignatureDate1);
                            termAverage.setText(termAverage1);
                            principalComments.setText(principalComments1);
                            promotion_Status.setText(promotionStatus1);
                            if (schoolTerm1.equals("3rd Term")){promotion_Status.setVisibility(View.VISIBLE); if (promotionStatus1.equals("Repeated")){promotion_Status.setTextColor(Color.RED);
                            }else{promotion_Status.setTextColor(Color.GREEN);}}

                            scrollView.setVisibility(View.VISIBLE);

                        }else{
                            //hiding scrollView.
                            scrollView.setVisibility(View.GONE);

                            //setting text to show dashes.
                            childID.setText("----");
                            childName.setText("----");
                            classID.setText("----");
                            schoolTerm.setText("----");
                            schoolYear.setText("----");

                            message.setText("ReportCard for "+FIRSTNAME +" "+ LASTNAME + " does not exist.\n" +
                                    "Consider using the ReportCard Search menu at the top right.");
                            message.setVisibility(View.VISIBLE);

                        }
                        progressBar.HideDialog();
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {

                    }
                });
                Toast.makeText(ReportCardView.this, FIRSTNAME+"'s Reportcard selected.", Toast.LENGTH_SHORT).show();

                dialog.dismiss();
            }
        });
        dialog.show();
        dialog.getWindow().setLayout(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.WRAP_CONTENT);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        dialog.getWindow().getAttributes().windowAnimations = R.style.DialogAnimation;
        dialog.getWindow().setGravity(Gravity.BOTTOM);

        search_header.setText(FIRSTNAME+"'s Reportcard search");

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_options, menu);
        return true;
    }

    @SuppressLint("NonConstantResourceId")
    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {

        switch (item.getItemId()){
            case R.id.menu_search:
                //shows the reportcard bottom sheet
                showDialog();
                break;
            case R.id.menu_logout:
                //allows user to re login when the app starts
                SharedPreferences preferences = getSharedPreferences("checkbox", MODE_PRIVATE);
                SharedPreferences.Editor editor = preferences.edit();
                editor.putString("remember", "false");
                editor.apply();

                startActivity(new Intent(getApplicationContext(), Login.class));
                break;
        }

        return super.onOptionsItemSelected(item);
    }

}
