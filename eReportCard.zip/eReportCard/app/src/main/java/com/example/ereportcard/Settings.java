package com.example.ereportcard;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.FirebaseDatabase;

import java.util.Objects;

public class Settings extends AppCompatActivity {
    
    TextView deleteAccount, help, appInfo, versionName, aboutUs;
    public String USERNAME;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);

        //getting username from the login screen
        USERNAME = getIntent().getStringExtra("userName");

        //changing the status bar color
        getWindow().setStatusBarColor(ContextCompat.getColor(this,R.color.purple_200));

        //changing the action bar color
        Objects.requireNonNull(getSupportActionBar()).setBackgroundDrawable(new ColorDrawable(Color.parseColor("#FFBB86FC")));

        Objects.requireNonNull(getSupportActionBar()).setTitle("Settings");
        
        deleteAccount = findViewById(R.id.txtDelete_Account);
        help = findViewById(R.id.txtHelp);
        appInfo = findViewById(R.id.txtApp_Info);
        versionName = findViewById(R.id.App_versionName);
        aboutUs = findViewById(R.id.txtAboutUs);

        versionName.setText(BuildConfig.VERSION_NAME);

        AlertDialog.Builder builder = new AlertDialog.Builder(this);

        deleteAccount.setOnClickListener(view -> builder.setTitle("WARNING").setMessage("Deleting your account will result in permanent data lose and can't be recovered. \n Are you sure?").setIcon(R.drawable.logo)
                        .setCancelable(true)
                        .setPositiveButton("Delete", (dialogInterface, i) -> {
                            FirebaseDatabase.getInstance().getReference("MobileUsers").child("Registered_Users").child(USERNAME).removeValue();
                            SharedPreferences preferences = getSharedPreferences("checkbox", MODE_PRIVATE);
                            SharedPreferences.Editor editor = preferences.edit();
                            editor.putString("remember", "false");
                            editor.apply();

                            Toast.makeText(Settings.this, "Account Deleted", Toast.LENGTH_SHORT).show();

                            //startActivity(new Intent(getApplicationContext(), SplashScreen.class));

                            Intent intent = new Intent(Settings.this, SplashScreen.class);
                            startActivity(intent);
                            finishAffinity();


                        })
                        .setNegativeButton("Cancel", (dialogInterface, i) -> dialogInterface.cancel())
                        .show());
        appInfo.setOnClickListener(view -> Toast.makeText(this, "App Version "+BuildConfig.VERSION_NAME, Toast.LENGTH_SHORT).show());

        aboutUs.setOnClickListener(view -> builder.setTitle("Version "+BuildConfig.VERSION_NAME)
                .setMessage("Copyright 2022 - Current. \n\n" +
                        "eReportCard767 for ANDROID.\n\n" +
                        "eReportCard767 for ANDROID Mobile is a product of 'Snowball Studios', whose sole purpose is helping " +
                        "curb global warming re paper production for School's Student Report cards.\n\n" +
                        "Ezekiel Cyrille (C.E.O)\nNelisha Francois (V.P / Financial aid)\n------- (P.R.O)\n------- (Secretary)\n" +
                        "------- (Treasurer)\n------- (Business Manager)\n\n\n" +
                        "This version of eRc is compiled by snowball_studios.eReportCard767@eRc.org").setIcon(R.drawable.logo)
                //.setCancelable(true)
                .setPositiveButton("CLOSE", (dialogInterface, i) -> dialogInterface.cancel())
                .show()
        );
        help.setOnClickListener(view -> startActivity(new Intent(getApplicationContext(), Help.class)));
    }
}