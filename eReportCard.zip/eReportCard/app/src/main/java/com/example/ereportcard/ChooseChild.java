package com.example.ereportcard;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.animation.AnimationUtils;
import android.view.animation.LayoutAnimationController;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.google.android.material.floatingactionbutton.ExtendedFloatingActionButton;
import com.google.firebase.database.FirebaseDatabase;

import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

public class ChooseChild extends AppCompatActivity {

    // add more schools to the schoolID array when other schools come onboard

    String[] schoolID = {"Atkinson Primary School" /*, "Castle Bruce Secondary"*/};
    String[] primaryID = {"Grade K", "Grade 1", "Grade 2", "Grade 3", "Grade 4", "Grade 5", "Grade 6"};

    //TODO
    //uncomment the secondaryID array once secondary schools come onboard

    //String[] secondaryID = {"1st Form", "2nd Form", "3rd Form", "4th Form", "5th Form"};

    TextView welcomeMsg;

    RecyclerView recyclerView;
    ChildAdapter childAdapter;

    ExtendedFloatingActionButton floatingActionButton;

    ProgressBar progressBar;

    AlertDialog dialog;


    public String CHILD_ID, FIRSTNAME1, FIRSTNAME, LASTNAME, LASTNAME1, SCHOOL, CLASS_ID, USERNAME;

    @SuppressLint("SetTextI18n")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_choose_child);

        //getting username from the login screen
        USERNAME = getIntent().getStringExtra("userName");

        welcomeMsg = (TextView)findViewById(R.id.welcome);
        welcomeMsg.setText("Hello "+USERNAME+"!\nSelect child below to view their eReportcard.");

        recyclerView = (RecyclerView)findViewById(R.id.recyclerView1);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        //changing the status bar color
        getWindow().setStatusBarColor(ContextCompat.getColor(this,R.color.purple_500));

        //changing the action bar color
        Objects.requireNonNull(getSupportActionBar()).setBackgroundDrawable(new ColorDrawable(Color.parseColor("#FF6200EE")));
        getSupportActionBar().setTitle("Choose Child");

        //recyclerview animation code
        LayoutAnimationController animationController = AnimationUtils.loadLayoutAnimation(this,R.anim.layout_animation_fall_down);
        recyclerView.setLayoutAnimation(animationController);


        floatingActionButton = (ExtendedFloatingActionButton) findViewById(R.id.fab_addChild);

        floatingActionButton.extend();

        progressBar = new ProgressBar(this);
        progressBar.ShowDialog("Loading Children...");



        FirebaseRecyclerOptions<ChildModel> options =
                new FirebaseRecyclerOptions.Builder<ChildModel>()
                        .setQuery(FirebaseDatabase.getInstance().getReference("MobileUsers").child("Registered_Users").child(USERNAME).child("childInfo"), ChildModel.class)
                        .build();

        childAdapter = new ChildAdapter(options);
        recyclerView.setAdapter(childAdapter);
        progressBar.HideDialog();


        //dialog
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Enter Child's Credentials");

        //inflate dialog
        View view = getLayoutInflater().inflate(R.layout.add_new_student_dialog, null);

        AutoCompleteTextView classSpinner;
        AutoCompleteTextView schoolSpinner;
        ArrayAdapter<String> adapterItem;

        classSpinner = view.findViewById(R.id.class_Spinner);
        schoolSpinner = view.findViewById(R.id.school_Spinner);

        adapterItem = new ArrayAdapter<>(this, R.layout.list_item, schoolID);

        schoolSpinner.setAdapter(adapterItem);



        schoolSpinner.setOnItemClickListener((adapterView, view17, i, l) -> {
            String schoolSelected = adapterView.getItemAtPosition(i).toString();
            if (schoolSelected.equals("Atkinson Primary School")){
                ArrayAdapter<String> adapterItem1;
                adapterItem1 = new ArrayAdapter<>(getApplicationContext(), R.layout.list_item, primaryID);
                classSpinner.setAdapter(adapterItem1);

            }/*else if (schoolSelected.equals("Castle Bruce Secondary")){
                ArrayAdapter<String> adapterItem1;
                adapterItem1 = new ArrayAdapter<>(getApplicationContext(), R.layout.list_item, secondaryID);
                classSpinner.setAdapter(adapterItem1);
            }*/
        });

        LinearLayout childID_Layout, firstName_Layout, lastName_Layout, school_layout, classID_Layout;

        childID_Layout = view.findViewById(R.id.studentID_Layout);
        firstName_Layout = view.findViewById(R.id.FirstName_Layout);
        lastName_Layout = view.findViewById(R.id.LastName_Layout);
        school_layout = view.findViewById(R.id.School_Layout);
        classID_Layout = view.findViewById(R.id.ClassID_Layout);

        EditText firstName, lastName, childID;

        firstName = view.findViewById(R.id.tvFirstName);
        lastName = view.findViewById(R.id.tvLastName);
        childID = view.findViewById(R.id.txtStudentID);
        childID.hasFocus();

        Button childID_Next, firstName_Next, lastName_Next, schoolID_Next, class_Next;
        childID_Next = view.findViewById(R.id.btnChildID_Next);
        firstName_Next = view.findViewById(R.id.btnFirstName_Next);
        lastName_Next = view.findViewById(R.id.btnLastName_Next);
        schoolID_Next = view.findViewById(R.id.btnSchoolID_Next);
        class_Next = view.findViewById(R.id.btnClass_Done);



        childID_Next.setOnClickListener(view1 -> {
            CHILD_ID = childID.getText().toString().toUpperCase();
            if (CHILD_ID.isEmpty()){
                Toast.makeText(ChooseChild.this, "Enter Child's I.D.", Toast.LENGTH_LONG).show();
            }else{
                childID_Layout.setVisibility(View.GONE);
                firstName_Layout.setVisibility(View.VISIBLE);
                firstName.requestFocus();
            }
        });

        firstName_Next.setOnClickListener(view12 -> {
            FIRSTNAME1 = firstName.getText().toString();
            if (FIRSTNAME1.isEmpty()){
                Toast.makeText(ChooseChild.this, "Required field.", Toast.LENGTH_LONG).show();
            }else {
                //making the first letter of the first name capital.
                FIRSTNAME = FIRSTNAME1.substring(0,1).toUpperCase()+FIRSTNAME1.substring(1).toLowerCase();
                firstName_Layout.setVisibility(View.GONE);
                lastName_Layout.setVisibility(View.VISIBLE);
                lastName.requestFocus();
            }
        });

        lastName_Next.setOnClickListener(view13 -> {
            LASTNAME1 = lastName.getText().toString();
            if (LASTNAME1.isEmpty()){
                Toast.makeText(ChooseChild.this, "Last name Required", Toast.LENGTH_LONG).show();
            }else {
                //making the first letter of the last name capital.
                LASTNAME = LASTNAME1.substring(0,1).toUpperCase()+LASTNAME1.substring(1).toLowerCase();
                lastName_Layout.setVisibility(View.GONE);
                school_layout.setVisibility(View.VISIBLE);

            }
        });

        schoolID_Next.setOnClickListener(view14 -> {
            SCHOOL = schoolSpinner.getText().toString();
            if (SCHOOL.isEmpty()){
                Toast.makeText(ChooseChild.this, "School Name Can not be Empty.", Toast.LENGTH_LONG).show();
            }else {
                school_layout.setVisibility(View.GONE);
                classID_Layout.setVisibility(View.VISIBLE);
            }
        });

        class_Next.setOnClickListener(view15 -> {
            CLASS_ID = classSpinner.getText().toString();
            if (CLASS_ID.isEmpty()){
                Toast.makeText(ChooseChild.this, "Class Name Required", Toast.LENGTH_LONG).show();
            }else {
                progressBar.ShowDialog("Saving Child's Information...");

                //inserting data into database
                Map<String, Object> map = new HashMap<>();
                map.put("firstName", FIRSTNAME);
                map.put("lastName", LASTNAME);
                map.put("school", schoolSpinner.getText().toString());
                map.put("classID", classSpinner.getText().toString());
                map.put("childID", CHILD_ID);
                map.put("userID", USERNAME);

                FirebaseDatabase.getInstance().getReference("MobileUsers").child("Registered_Users").child(USERNAME).child("childInfo").child(CHILD_ID).setValue(map)
                        .addOnSuccessListener(unused -> {
                            progressBar.HideDialog();
                            Toast.makeText(ChooseChild.this, "Successfully Inserted.", Toast.LENGTH_SHORT).show();

                            firstName.setText("");
                            lastName.setText("");
                            childID.setText("");
                            classSpinner.setText("");
                            schoolSpinner.setText("");

                        })
                        .addOnFailureListener(e -> Toast.makeText(ChooseChild.this, "Error While Inserting.", Toast.LENGTH_SHORT).show());
                dialog.dismiss();
            }
        });
        builder.setView(view);
        dialog = builder.create();



        floatingActionButton.setOnClickListener(view16 -> {
            childID_Layout.setVisibility(View.VISIBLE);
            firstName_Layout.setVisibility(View.GONE);
            lastName_Layout.setVisibility(View.GONE);
            school_layout.setVisibility(View.GONE);
            classID_Layout.setVisibility(View.GONE);

            floatingActionButton.shrink();

            dialog.show();
        });
    }
    @Override
    protected void onStart() {

        super.onStart();
        childAdapter.startListening();
    }

    @Override
    protected void onStop() {

        super.onStop();
        childAdapter.startListening();
    }

    //to run animation after changing data.
    @SuppressLint("NotifyDataSetChanged")
    private void runLayoutAnimation(RecyclerView recyclerView){
        Context context = recyclerView.getContext();

        LayoutAnimationController layoutAnimationController =
                AnimationUtils.loadLayoutAnimation(context,R.anim.layout_animation_fall_down);

        recyclerView.setLayoutAnimation(layoutAnimationController);
        Objects.requireNonNull(recyclerView.getAdapter()).notifyDataSetChanged();
        recyclerView.scheduleLayoutAnimation();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.choose_child_menu_options, menu);
        return true;
    }

    @SuppressLint("NonConstantResourceId")
    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {

        switch (item.getItemId()){
            case R.id.menu_settings:
                Intent intent = new Intent(getApplicationContext(), Settings.class);
                intent.putExtra("userName",USERNAME);
                startActivity(intent);
                break;
            case R.id.menu_logout:
                //allows user to re login when the app starts
                SharedPreferences preferences = getSharedPreferences("checkbox", MODE_PRIVATE);
                SharedPreferences.Editor editor = preferences.edit();
                editor.putString("remember", "false");
                editor.apply();

                startActivity(new Intent(getApplicationContext(), Login.class));
                break;
        }

        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onBackPressed() {
        //checking if user selected remember me while login in on new app startup.
        SharedPreferences preferences = getSharedPreferences("checkbox", MODE_PRIVATE);
        String checkbox = preferences.getString("remember", "");

        finishAffinity();
    }

}