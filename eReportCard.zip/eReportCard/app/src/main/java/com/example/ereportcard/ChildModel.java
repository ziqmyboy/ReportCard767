package com.example.ereportcard;

public class ChildModel {
    String firstName, lastName, childID, school, classID, userID;

    //empty constructor needed for firebase
    ChildModel()
    {

    }

    public ChildModel(String firstName, String lastName, String childID, String school, String classID, String userID) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.childID = childID;
        this.school = school;
        this.classID = classID;
        this.userID = userID;

    }

    public String getFirstName() {
        return firstName;
    }


    public String getLastName() {
        return lastName;
    }

    public String getChildID() {
        return childID;
    }

    public String getSchool() {
        return school;
    }

    public String getClassID() {
        return classID;
    }

    public String getUserID() {
        return userID;
    }
}
