package com.example.ereportcard;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class CourseAdapter extends RecyclerView.Adapter<CourseAdapter.MyViewHolder> {

    Context context;

    ArrayList<Course_Data> list;

    public CourseAdapter(Context context, ArrayList<Course_Data> list) {
        this.context = context;
        this.list = list;
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(context).inflate(R.layout.item, parent, false);
        return new MyViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {

        Course_Data course_data = list.get(position);
        holder.courseName.setText(course_data.getCourseName());
        holder.courseTermGrade.setText(course_data.getCourseTermGrade());
        holder.courseExamGrade.setText(course_data.getCourseExamGrade());
        holder.courseTeacher.setText(course_data.getCourseTeacher());
        holder.courseComment.setText(course_data.getCourseComments());
        holder.id.setText(course_data.getId());
    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    public static class MyViewHolder extends RecyclerView.ViewHolder{

        TextView courseName, courseTermGrade, courseExamGrade, courseTeacher, courseComment, id;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);

            courseName = itemView.findViewById(R.id.lblCourseName);
            courseTermGrade = itemView.findViewById(R.id.lblTermGrade);
            courseExamGrade = itemView.findViewById(R.id.lblExamGrade);
            courseTeacher = itemView.findViewById(R.id.lblTeacherName);
            courseComment = itemView.findViewById(R.id.lblComments);
            id = itemView.findViewById(R.id.lblID);

        }
    }

}
